from nltk.tokenize import word_tokenize

oracion="We need to conduct an assessment to learn whether a student's dificulties are because he or she can't or won't complete assignments."
tokens=word_tokenize(oracion)
print(tokens)
